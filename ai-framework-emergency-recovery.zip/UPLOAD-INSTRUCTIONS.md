# AI Framework emergency recovery

This update removes the phrase "Stop collecting AI tools" and fixes the
JavaScript loop that can freeze the site.

## Upload first

In the `ai-framework-live` GitHub repository, open `static/js` and replace:

- `site-enhancements.js`

Commit this file first with:

`Recover site and correct homepage message`

## Upload after the site recovers

At the repository root, replace:

- `index.html`
- `social-card.png`
- `social-card.svg`

Commit these three root files with:

`Update AI Framework positioning`

The replacement message is:

`Find the right AI tools. Build a working AI system.`

Do not upload this ZIP itself to GitHub. Extract it first and upload the files
to the exact locations above.
